package com.example.se2tut2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Se2Tut2Application {

	public static void main(String[] args) {
		SpringApplication.run(Se2Tut2Application.class, args);
	}

}
