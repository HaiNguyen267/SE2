package com.example.se2tut2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Se2Tut2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
